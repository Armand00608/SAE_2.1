package exFinal.Ihm;

import exFinal.Controleur;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

public class BarreMenu extends JMenuBar implements ActionListener {
	private JMenuItem menuiSauv;
	private JMenuItem menuiAjou;
	private JMenuItem menuiSupp;
	private JMenuItem menuiDure;

	private Controleur ctrl;
	private FrameAjout frameAjout;

	public BarreMenu(Controleur ctrl){

		this.ctrl = ctrl;
		JMenu menuFichier = new JMenu("Fichier");
		JMenu menuEdition = new JMenu("Edition");

		this.menuiSauv = new JMenuItem("Enregistrer");

		this.menuiAjou = new JMenuItem("Ajouter");
		this.menuiSupp = new JMenuItem("Supprimer");
		this.menuiDure = new JMenuItem("Changer Durée");

		menuFichier.add(this.menuiSauv);

		menuEdition.add(this.menuiAjou);
		menuEdition.add(this.menuiSupp);
		menuEdition.addSeparator();
		menuEdition.add(this.menuiDure);

		this.add(menuFichier);
		this.add(menuEdition);

		this.menuiSauv.addActionListener(this);
		this.menuiSupp.addActionListener(this);
		this.menuiDure.addActionListener(this);
		this.menuiAjou.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == this.menuiAjou)
		{
			frameAjout = new FrameAjout(this.ctrl);
		}

		if (e.getSource() == this.menuiSupp)
		{

		}

		if (e.getSource() == this.menuiSauv) 
		{
			// 1. Créer une boîte de dialogue pour choisir le fichier
			JFileChooser dialogueEnregistrement = new JFileChooser();
			dialogueEnregistrement.setDialogTitle("Enregistrer les positions sous...");
			//ouvrir le jFileChooser dans l'emplacement courant	
			dialogueEnregistrement.setCurrentDirectory(new File("./enreg"));
		
			// 2. Suggérer un nom de fichier par défaut (très recommandé pour l'utilisateur)
			dialogueEnregistrement.setSelectedFile(new File("mon_projet_mpm.txt"));
		
			// 3. Afficher la boîte de dialogue et attendre le choix de l'utilisateur
			int choixUtilisateur = dialogueEnregistrement.showSaveDialog(this.getParent());
		
			// 4. Vérifier si l'utilisateur a cliqué sur "Enregistrer"
			if (choixUtilisateur == JFileChooser.APPROVE_OPTION) 
			{
				
				// 5. Récupérer le fichier et son chemin complet
				File fichierAEnregistrer = dialogueEnregistrement.getSelectedFile();
				String cheminAbsolu = fichierAEnregistrer.getAbsolutePath();
		
				System.out.println("L'utilisateur a choisi d'enregistrer ici : " + cheminAbsolu);
				
				this.ctrl.enregistrer(cheminAbsolu);
			} 
			else {
				// L'utilisateur a cliqué sur "Annuler" ou a fermé la fenêtre
				System.out.println("Enregistrement annulé par l'utilisateur.");
			}
		}
	}
}
