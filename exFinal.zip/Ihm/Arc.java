package exFinal.Ihm;

public class Arc
{
	String from, to;
	int poids;

	Arc(String from, String to, int poids)
	{
		this.from = from;
		this.to = to;
		this.poids = poids;
	}
}